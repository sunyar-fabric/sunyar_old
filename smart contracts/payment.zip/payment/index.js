/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const payment = require('./lib/payment');

module.exports.Payment = payment;
module.exports.contracts = [payment];
