const GlobalExceptions = {
  common: {
    inputError: {
      code: 1,
      message: "Input values cannot be empty",
      httpStatusCode: 400,
    }
  },
  plan: {
    Existence: {
      code: 2,
      message: "Plan already exists",
      httpStatusCode: 400,
    }
  }
};

module.exports = { GlobalExceptions };
