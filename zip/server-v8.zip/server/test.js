let sentence = "this has error for your server"
console.log(sentence.includes("error"));