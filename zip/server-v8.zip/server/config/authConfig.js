
module.exports = {
    jwtPrivateKey: 'suny@r1400!AaBb'
}